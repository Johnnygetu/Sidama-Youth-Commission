<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    echo json_encode([
        'success' => false,
        'message' => 'Only PUT method allowed',
        'data' => null
    ]);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Message ID is required',
        'data' => null
    ]);
    exit();
}

if (!isset($input['reply']) || empty(trim($input['reply']))) {
    echo json_encode([
        'success' => false,
        'message' => 'Reply content is required',
        'data' => null
    ]);
    exit();
}

try {
    $pdo = new PDO('mysql:host=eltechsolutions-et.com;dbname=eltechev_sidamaYouthComission;charset=utf8mb4', 'eltechev_syc', 'Qwertyuiop123');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get message details for email
    $stmt = $pdo->prepare('SELECT name, email, subject, message FROM contact_messages WHERE id = ?');
    $stmt->execute([$input['id']]);
    $message = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$message) {
        throw new Exception('Message not found');
    }

    // Update message status
    $pdo->prepare('UPDATE contact_messages SET status = ?, updated_at = NOW() WHERE id = ?')->execute(['replied', $input['id']]);

    // Send email reply
    try {
        require_once __DIR__ . '/../utils/simple_mailer_fixed.php';
        $mailer = new SimpleMailerFixed();
        $emailSent = $mailer->sendReply(
            $message['email'],
            $message['name'],
            $message['subject'],
            $message['message'],
            $input['reply']
        );

        // Log the result for debugging
        error_log("Email sending attempt - Success: " . ($emailSent ? 'true' : 'false') .
            " - To: " . $message['email'] .
            " - Subject: " . $message['subject']);
    } catch (Exception $e) {
        error_log("Email sending error: " . $e->getMessage());
        $emailSent = false;
    }

    if ($emailSent) {
        echo json_encode([
            'success' => true,
            'message' => 'Reply sent successfully and message marked as replied',
            'data' => ['id' => $input['id']]
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Message marked as replied but email could not be sent',
            'data' => ['id' => $input['id']]
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'data' => null
    ]);
}
